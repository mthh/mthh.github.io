#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from flask import Flask, render_template, request, url_for, redirect
from flask_sqlalchemy import SQLAlchemy
from datetime import date
import os

basedir = os.path.abspath(os.path.dirname(__file__))

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'app.db')
db = SQLAlchemy(app)


class Review(db.Model):
    id_review = db.Column(db.Integer, primary_key=True)
    rate = db.Column(db.Integer, nullable=False)
    comment = db.Column(db.String(255))
    name=db.Column(db.String())


@app.route("/", methods=['GET', 'POST'])
@app.route('/index', methods=['GET', 'POST'])
def root():
    if request.method == 'GET':
        all_reviews = Review.query.all()
        return render_template('index.html',
                                list_reviews=all_reviews,
                                nb_reviews = len(all_reviews),
                                current_date=date.today().isoformat())
    elif request.method == 'POST':
        new_review = Review(
            rate=request.form['rate'],
            comment=request.form['comment'],
            name=request.form['name'],
        )
        db.session.add(new_review)
        db.session.commit()
        return redirect(url_for('root'))

# Ce morceau de code sert à créer la base de données avec les memes entrées
# que celles utilisées dans le TP 5.
# Il sert à créer le fichier `app.db` qui a été fournit, il ne sera donc pas éxécuté.
# Pour l'exécuter, il faut saisir `flask init_db` dans le dossier avant le 1er
# démarage de l'application, dans le dossier où vous vous apprêtez
# à saisir `flask run` pour démarrer l'application
@app.cli.command("init_db")
def init_db():
    db.create_all()
    entries = [
     {"id_review": 1, "rate": 5, "comment": "Mattis molestie a iaculis at erat pellentesque adipiscing commodo."},
     {"id_review": 2, "rate": 4, "comment": "Amet massa vitae tortor condimentum lacinia."},
     {"id_review": 3, "rate": 3, "comment": "Imperdiet sed euismod nisi porta lorem mollis aliquam."},
     {"id_review": 4, "rate": 1, "comment": "Dignissim enim sit amet venenatis. Urna cursus eget nunc scelerisque."},
     {"id_review": 5, "rate": 4, "comment": "A pellentesque sit amet porttitor eget dolor morbi."},
     {"id_review": 6, "rate": 3, "comment": "Consequat nisl vel pretium lectus quam id leo in vitae."},
    ]

    for e in entries:
        a = Review(id_review = e['id_review'], rate = e['rate'], comment = e['comment'])
        db.session.add(a)
    db.session.commit()

