#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from flask import Flask, render_template, request, url_for, redirect
from flask_sqlalchemy import SQLAlchemy
from datetime import date
import os

basedir = os.path.abspath(os.path.dirname(__file__))

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'app.db')
db = SQLAlchemy(app)


class Review(db.Model):
    id_review = db.Column(db.Integer, primary_key=True)
    rate = db.Column(db.Integer, nullable=False)
    comment = db.Column(db.String(255))
    name=db.Column(db.String())
    latitude=db.Column(db.Float(precision=10), nullable=False)
    longitude=db.Column(db.Float(precision=10), nullable=False)


@app.route("/", methods=['GET', 'POST'])
@app.route('/index', methods=['GET', 'POST'])
def root():
    if request.method == 'GET':
        all_reviews = Review.query.all()
        return render_template('index.html',
                                list_reviews=all_reviews,
                                nb_reviews = len(all_reviews),
                                current_date=date.today().isoformat())
    elif request.method == 'POST':
        new_review = Review(
            rate=request.form['rate'],
            comment=request.form['comment'],
            name=request.form['name'],
        )
        db.session.add(new_review)
        db.session.commit()
        return redirect(url_for('root'))


@app.cli.command("init_db")
def init_db():
    db.create_all()
    entries = [
        {
            "id_review": 1, "rate": 5, "name": "Cameran Duran",
            "comment": "Mattis molestie a iaculis at erat pellentesque adipiscing commodo.",
            "latitude": 45.191337695481465, "longitude": 5.770000219345093,
        },
        {
            "id_review": 2, "rate": 4, "name": "Nasim Erickson",
            "comment": "Amet massa vitae tortor condimentum lacinia.",
            "latitude": 45.191511599498966, "longitude": 5.773272514343263,

        },
        {
            "id_review": 3, "rate": 3, "name": "Guy Richardson",
            "comment": "Imperdiet sed euismod nisi porta lorem mollis aliquam.",
            "latitude": 45.19229038053758, "longitude": 5.772736072540284,
        },
        {
            "id_review": 4, "rate": 1, "name": "Veda Lott",
            "comment": "Dignissim enim sit amet venenatis. Urna cursus eget nunc scelerisque.",
            "latitude": 45.19298128053758, "longitude": 5.7674560725456148,
        },
        {
            "id_review": 5, "rate": 4, "name": "Flavia Klein",
            "comment": "A pellentesque sit amet porttitor eget dolor morbi.",
            "latitude": 45.19347891765491, "longitude": 5.772561599498966,
        },
    ]

    for e in entries:
        a = Review(
            id_review = e['id_review'],
            name = e['name'],
            rate = e['rate'],
            comment = e['comment'],
            latitude = e['latitude'],
            longitude = e['longitude'],
        )
        db.session.add(a)
    db.session.commit()
